## **Description**

A collection of mods for the Xiaomi Mi A1

## **Changelog**

**0.1**  
Enabled Camera 2 API  
Added EIS Fix  
Fixed Noise Cancellation  
Fixed Camera Launch lag experienced when system is rooted.  
Added Pixel specific (ring)tones/alarms/ui sounds  

**0.2**  
Added InterUI Font  

**0.3**  
Inverted button layout